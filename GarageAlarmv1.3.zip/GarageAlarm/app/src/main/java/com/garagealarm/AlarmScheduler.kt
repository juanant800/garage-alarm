package com.garagealarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

object AlarmScheduler {
    const val ACTION_FIRE = "com.garagealarm.FIRE"
    const val EXTRA_ID = "alarm_id"
    const val EXTRA_REPEAT = "repeat_index"

    private fun fireIntent(c: Context, id: Int, repeat: Int, snooze: Boolean): PendingIntent {
        val i = Intent(c, AlarmReceiver::class.java).setAction(ACTION_FIRE)
            .putExtra(EXTRA_ID, id).putExtra(EXTRA_REPEAT, repeat)
        val code = if (snooze) id + 1_000_000 else id
        return PendingIntent.getBroadcast(c, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun showIntent(c: Context): PendingIntent =
        PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)

    private fun am(c: Context) = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    /** Programa la proxima ocurrencia. setAlarmClock = exacta, sobrevive a Doze y no pide permisos especiales. */
    fun schedule(c: Context, a: Alarm, from: Long = System.currentTimeMillis()) {
        cancel(c, a.id)
        if (!a.enabled) return
        val t = nextTrigger(a, from)
        am(c).setAlarmClock(AlarmManager.AlarmClockInfo(t, showIntent(c)), fireIntent(c, a.id, 0, false))
    }

    fun scheduleSnooze(c: Context, a: Alarm, repeatIndex: Int, atMs: Long) {
        am(c).setAlarmClock(AlarmManager.AlarmClockInfo(atMs, showIntent(c)), fireIntent(c, a.id, repeatIndex, true))
    }

    fun cancel(c: Context, id: Int) {
        am(c).cancel(fireIntent(c, id, 0, false))
        am(c).cancel(fireIntent(c, id, 0, true))
    }

    fun canScheduleExact(c: Context): Boolean =
        Build.VERSION.SDK_INT < 31 || am(c).canScheduleExactAlarms()

    fun rescheduleAll(c: Context) {
        AlarmRepo.load(c).forEach {
            if (it.enabled) {
                try { schedule(c, it) } catch (e: SecurityException) { }
            }
        }
    }
}
