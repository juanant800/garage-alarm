package com.garagealarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getIntExtra(AlarmScheduler.EXTRA_ID, -1)
        val rep = i.getIntExtra(AlarmScheduler.EXTRA_REPEAT, 0)
        val a = AlarmRepo.get(c, id) ?: return
        if (!a.enabled && rep == 0) return
        if (rep == 0) {
            if (a.days == 0) AlarmRepo.upsert(c, a.copy(enabled = false)) // alarma de una sola vez
            else AlarmScheduler.schedule(c, a, System.currentTimeMillis() + 30_000L) // siguiente dia
        }
        val s = Intent(c, AlarmService::class.java).setAction(AlarmService.ACTION_START)
            .putExtra(AlarmScheduler.EXTRA_ID, id).putExtra(AlarmScheduler.EXTRA_REPEAT, rep)
        ContextCompat.startForegroundService(c, s)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        AlarmScheduler.rescheduleAll(c)
    }
}
