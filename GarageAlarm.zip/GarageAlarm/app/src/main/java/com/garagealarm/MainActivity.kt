package com.garagealarm

import android.Manifest
import android.app.NotificationManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import java.io.File

class MainActivity : ComponentActivity() {
    private val vm: AlarmViewModel by viewModels()
    private var issue by mutableStateOf<PermIssue?>(null)
    private var crashText by mutableStateOf<String?>(null)

    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { refreshIssue() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val f = File(filesDir, "crash.txt")
        if (f.exists()) crashText = try { f.readText().take(3500) } catch (e: Exception) { null }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent {
            GarageTheme {
                val c = crashText
                if (c != null) {
                    CrashScreen(
                        c,
                        onCopy = { copyText(c) },
                        onClearAlarms = { clearAll() },
                        onContinue = { dismissCrash() }
                    )
                } else {
                    App(vm, issue) { fixIssue() }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        try {
            vm.reload()
            refreshIssue()
            AlarmScheduler.rescheduleAll(this)
        } catch (e: Throwable) {
            if (crashText == null) crashText = "Error al iniciar:\n" + e.stackTraceToString().take(3500)
        }
    }

    private fun copyText(t: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("error", t))
        Toast.makeText(this, "Copiado", Toast.LENGTH_SHORT).show()
    }

    private fun dismissCrash() {
        try { File(filesDir, "crash.txt").delete() } catch (e: Exception) {}
        crashText = null
    }

    private fun clearAll() {
        getSharedPreferences("garage_alarms", Context.MODE_PRIVATE).edit().clear().apply()
        try { vm.reload() } catch (e: Throwable) {}
        dismissCrash()
    }

    private fun refreshIssue() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        issue = when {
            !nm.areNotificationsEnabled() ->
                PermIssue("Activa las notificaciones para que la alarma pueda mostrarse con la pantalla bloqueada.", "Activar")
            Build.VERSION.SDK_INT >= 34 && !nm.canUseFullScreenIntent() ->
                PermIssue("Permite las notificaciones a pantalla completa para que la alarma aparezca al sonar.", "Permitir")
            else -> null
        }
    }

    private fun fixIssue() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val i = if (!nm.areNotificationsEnabled()) {
            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
        } else if (Build.VERSION.SDK_INT >= 34) {
            Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName"))
        } else return
        startActivity(i)
    }
}
