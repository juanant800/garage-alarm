package com.garagealarm

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/** days: mascara de bits, Lun=1, Mar=2, Mie=4, Jue=8, Vie=16, Sab=32, Dom=64. 0 = una sola vez. */
data class Alarm(
    val id: Int,
    val hour: Int,
    val minute: Int,
    val days: Int = 0,
    val label: String = "",
    val carId: String = "f8",
    val enabled: Boolean = true,
    val repeatEnabled: Boolean = true,
    val repeatMinutes: Int = 5,
    val repeatTimes: Int = 3,
    val idleSeconds: Int = 8,
    val rampSeconds: Int = 45,
    val vibrate: Boolean = true
)

private fun dayIndex(cal: Calendar): Int = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7 // Lun=0 .. Dom=6

fun nextTrigger(a: Alarm, from: Long): Long {
    val cal = Calendar.getInstance()
    cal.timeInMillis = from
    cal.set(Calendar.HOUR_OF_DAY, a.hour)
    cal.set(Calendar.MINUTE, a.minute)
    cal.set(Calendar.SECOND, 0)
    cal.set(Calendar.MILLISECOND, 0)
    for (i in 0..8) {
        if (cal.timeInMillis > from && (a.days == 0 || (a.days and (1 shl dayIndex(cal))) != 0)) return cal.timeInMillis
        cal.add(Calendar.DAY_OF_YEAR, 1)
    }
    return cal.timeInMillis
}

fun describeUntil(target: Long, now: Long): String {
    val mins = ((target - now + 59_999L) / 60000L).toInt()
    val d = mins / 1440
    val h = (mins % 1440) / 60
    val m = mins % 60
    val parts = ArrayList<String>()
    if (d > 0) parts.add("$d d")
    if (h > 0) parts.add("$h h")
    if (m > 0 || parts.isEmpty()) parts.add("$m min")
    return parts.joinToString(" ")
}

fun daysText(days: Int): String {
    val names = listOf("Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom")
    return when (days) {
        0 -> "Una vez"
        127 -> "Todos los días"
        31 -> "Lun a Vie"
        96 -> "Sáb y Dom"
        else -> names.filterIndexed { i, _ -> (days and (1 shl i)) != 0 }.joinToString(", ")
    }
}

object AlarmRepo {
    private fun prefs(c: Context) = c.getSharedPreferences("garage_alarms", Context.MODE_PRIVATE)

    fun load(c: Context): List<Alarm> {
        val raw = prefs(c).getString("alarms", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Alarm(
                    id = o.getInt("id"), hour = o.getInt("hour"), minute = o.getInt("minute"),
                    days = o.optInt("days", 0), label = o.optString("label", ""),
                    carId = o.optString("carId", "f8"), enabled = o.optBoolean("enabled", true),
                    repeatEnabled = o.optBoolean("repeatEnabled", true),
                    repeatMinutes = o.optInt("repeatMinutes", 5), repeatTimes = o.optInt("repeatTimes", 3),
                    idleSeconds = o.optInt("idleSeconds", 8), rampSeconds = o.optInt("rampSeconds", 45),
                    vibrate = o.optBoolean("vibrate", true)
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(c: Context, list: List<Alarm>) {
        val arr = JSONArray()
        list.forEach { a ->
            arr.put(
                JSONObject().put("id", a.id).put("hour", a.hour).put("minute", a.minute).put("days", a.days)
                    .put("label", a.label).put("carId", a.carId).put("enabled", a.enabled)
                    .put("repeatEnabled", a.repeatEnabled).put("repeatMinutes", a.repeatMinutes)
                    .put("repeatTimes", a.repeatTimes).put("idleSeconds", a.idleSeconds)
                    .put("rampSeconds", a.rampSeconds).put("vibrate", a.vibrate)
            )
        }
        prefs(c).edit().putString("alarms", arr.toString()).apply()
    }

    fun get(c: Context, id: Int): Alarm? = load(c).firstOrNull { it.id == id }

    fun upsert(c: Context, a: Alarm) {
        val list = load(c).toMutableList()
        val i = list.indexOfFirst { it.id == a.id }
        if (i >= 0) list[i] = a else list.add(a)
        save(c, list)
    }

    fun defaultCar(c: Context): String = prefs(c).getString("default_car", "f8") ?: "f8"
    fun setDefaultCar(c: Context, id: String) = prefs(c).edit().putString("default_car", id).apply()
}
