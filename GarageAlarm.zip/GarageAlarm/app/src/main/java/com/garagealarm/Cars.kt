package com.garagealarm

/** Silueta lateral en un viewBox de 120x40 (morro a la derecha). */
data class Silhouette(
    val body: String,
    val rearX: Float,
    val frontX: Float,
    val rects: List<FloatArray> = emptyList()
)

data class CarProfile(
    val id: String,
    val name: String,
    val engine: String,
    val cyl: Int,
    val idleRpm: Double,
    val redRpm: Double,
    val pulseK: Double,   // nitidez del pulso de combustion (mas alto = mas agresivo)
    val cutLow: Double,   // corte del filtro a ralenti (Hz)
    val cutHigh: Double,  // corte del filtro a regimen alto (Hz)
    val drive: Double,    // saturacion / rugido
    val lump: Double,     // irregularidad del ralenti
    val turbo: Double,    // silbido de turbo + valvula de descarga
    val pop: Double,      // petardeos al soltar
    val boom: Double,     // cuerpo grave del escape
    val riseTau: Double,  // rapidez al subir de vueltas (s)
    val sil: Silhouette
)

object Cars {
    val all: List<CarProfile> = listOf(
        CarProfile(
            "f8", "Ferrari F8", "V8 biturbo", 8, 950.0, 8000.0, 40.0, 900.0, 5500.0, 1.6, 0.10, 0.5, 0.6, 0.5, 0.10,
            Silhouette("M4 31 L4 25 Q5 22 10 21.5 L34 20 Q44 18 52 13 Q58 10.5 68 10.5 Q76 10.5 82 14 L98 21 Q108 23 114 26 Q117 28 117 31 Z", 30f, 94f)
        ),
        CarProfile(
            "mustang", "Mustang GT", "V8 5.0", 8, 750.0, 7000.0, 22.0, 500.0, 3500.0, 2.0, 0.35, 0.0, 0.3, 1.0, 0.17,
            Silhouette("M3 32 L3 23 Q3 19 8 18.5 L16 18 L36 10.5 Q44 6.5 56 6.5 Q68 6.5 74 8.5 L88 17 L108 19.5 Q116 20.5 117 26 L117 32 Z", 31f, 95f)
        ),
        CarProfile(
            "r34", "Nissan Skyline R34", "6 en línea turbo", 6, 900.0, 8000.0, 28.0, 700.0, 4500.0, 1.5, 0.08, 1.0, 0.9, 0.6, 0.12,
            Silhouette("M4 32 L4 19 L4.5 12 L17 12 L17 15 L30 17.5 L40 17 L46 7.5 Q48 6 52 6 L70 6 Q74 6 78 9 L88 16.5 L108 19 Q115 20 117 27 L117 32 Z", 30f, 95f)
        ),
        CarProfile(
            "gt3", "Porsche 911 GT3", "Bóxer 6 atmosférico", 6, 900.0, 9000.0, 34.0, 900.0, 6500.0, 1.3, 0.12, 0.0, 0.2, 0.35, 0.07,
            Silhouette(
                "M4 32 L4 25 Q5 22 10 21.5 Q30 19 44 10 Q52 7.5 62 7.5 Q74 7.5 80 11 L92 19 Q106 21 112 24 Q117 26 117 32 Z", 34f, 94f,
                listOf(floatArrayOf(3f, 14f, 24f, 2.6f), floatArrayOf(11f, 16f, 2.4f, 6f), floatArrayOf(19f, 16f, 2.4f, 6f))
            )
        ),
        CarProfile(
            "supra", "Toyota Supra", "2JZ turbo", 6, 850.0, 7000.0, 26.0, 650.0, 4000.0, 1.7, 0.10, 0.9, 0.8, 0.6, 0.13,
            Silhouette("M4 32 L4 23 Q5 20 10 19.5 L26 18.5 Q36 17 44 11 Q50 7.5 60 7.5 Q70 7.5 76 10 L88 18 L106 21.5 Q116 22.5 117 27 L117 32 Z", 30f, 93f)
        ),
        CarProfile(
            "m4e46", "BMW M4 E46", "6 en línea 3.2 atmosférico", 6, 850.0, 8000.0, 36.0, 800.0, 6000.0, 1.3, 0.07, 0.0, 0.3, 0.45, 0.09,
            Silhouette("M4 32 L4 21 Q4 18.5 8 18.5 L30 17.5 Q36 17 42 10 Q45 5.5 54 5.5 L70 5.5 Q76 6 82 11 L92 17.5 L108 20 Q115 21 117 25 L117 32 Z", 27f, 95f)
        ),
        CarProfile(
            "m5e60", "BMW M5 E60", "V10 5.0 atmosférico", 10, 750.0, 8250.0, 42.0, 850.0, 7000.0, 1.4, 0.09, 0.0, 0.5, 0.45, 0.08,
            Silhouette("M3 32 L3 18 Q3 15.5 8 15.5 L28 15 Q36 14.5 41 10 Q45 5.5 56 5.5 L72 5.5 Q80 6 86 11 L95 17.5 L110 20 Q116 21 117 25 L117 32 Z", 28f, 97f)
        )
    )

    fun byId(id: String): CarProfile = all.firstOrNull { it.id == id } ?: all[0]
}
