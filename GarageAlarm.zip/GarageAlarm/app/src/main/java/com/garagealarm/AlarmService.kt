package com.garagealarm

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat

class AlarmService : Service() {
    companion object {
        const val ACTION_START = "com.garagealarm.START"
        const val ACTION_STOP = "com.garagealarm.STOP"
        const val ACTION_SNOOZE = "com.garagealarm.SNOOZE"
        const val ACTION_DONE = "com.garagealarm.DONE"
        const val CHANNEL = "garage_alarm_ring"
        const val NOTIF_ID = 4242
        const val MAX_RING_MS = 5 * 60 * 1000L
    }

    private var player: EnginePlayer? = null
    private var alarm: Alarm? = null
    private var repeatIndex = 0
    private var wake: PowerManager.WakeLock? = null
    private var vibrator: Vibrator? = null
    private var finished = false
    private val handler = Handler(Looper.getMainLooper())
    private val timeout = Runnable { snoozeIfPossible() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> finishAlarm()
            ACTION_SNOOZE -> snoozeIfPossible()
            else -> if (intent != null) startRinging(intent) else stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun ensureChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(CHANNEL, "Alarma sonando", NotificationManager.IMPORTANCE_HIGH)
        ch.setSound(null, null)
        ch.enableVibration(false)
        ch.lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
        nm.createNotificationChannel(ch)
    }

    private fun startRinging(intent: Intent) {
        ensureChannel()
        val id = intent.getIntExtra(AlarmScheduler.EXTRA_ID, -1)
        val a = AlarmRepo.get(this, id)
        if (a == null) { // alarma borrada: hay que llamar a startForeground igualmente
            val n = NotificationCompat.Builder(this, CHANNEL).setSmallIcon(R.drawable.ic_stat_alarm).setContentTitle("Alarma").build()
            startForeground(NOTIF_ID, n)
            finishAlarm()
            return
        }
        cleanup()
        finished = false
        alarm = a
        repeatIndex = intent.getIntExtra(AlarmScheduler.EXTRA_REPEAT, 0)
        val car = Cars.byId(a.carId)

        val notif = buildNotification(a, car)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF_ID, notif)
        }

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "garagealarm:ring").also { it.acquire(MAX_RING_MS + 30_000L) }

        player = EnginePlayer(applicationContext).also { it.start(car, a.idleSeconds, a.rampSeconds, 0.25f) }

        if (a.vibrate) startVibration(a)
        handler.postDelayed(timeout, MAX_RING_MS)
    }

    @Suppress("DEPRECATION")
    private fun startVibration(a: Alarm) {
        val v = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        vibrator = v
        val delay = ((3.0 + a.idleSeconds) * 1000).toLong() // vibra cuando empiezan las aceleradas
        val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        v.vibrate(VibrationEffect.createWaveform(longArrayOf(delay, 600, 500), 1), attrs)
    }

    private fun buildNotification(a: Alarm, car: CarProfile): android.app.Notification {
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val open = Intent(this, AlarmActivity::class.java)
            .putExtra(AlarmScheduler.EXTRA_ID, a.id).putExtra(AlarmScheduler.EXTRA_REPEAT, repeatIndex)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val fs = PendingIntent.getActivity(this, 1, open, flags)
        val stopPi = PendingIntent.getService(this, 2, Intent(this, AlarmService::class.java).setAction(ACTION_STOP), flags)
        val title = if (a.label.isBlank()) "Alarma" else a.label
        val b = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_alarm)
            .setContentTitle(title)
            .setContentText("%02d:%02d · %s".format(a.hour, a.minute, car.name))
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setContentIntent(fs)
            .setFullScreenIntent(fs, true)
        if (canSnooze(a)) {
            val snoozePi = PendingIntent.getService(this, 3, Intent(this, AlarmService::class.java).setAction(ACTION_SNOOZE), flags)
            b.addAction(0, "Posponer ${a.repeatMinutes} min", snoozePi)
        }
        b.addAction(0, "Apagar", stopPi)
        return b.build()
    }

    private fun canSnooze(a: Alarm) = a.repeatEnabled && repeatIndex < a.repeatTimes

    private fun snoozeIfPossible() {
        val a = alarm
        if (a != null && canSnooze(a)) {
            AlarmScheduler.scheduleSnooze(this, a, repeatIndex + 1, System.currentTimeMillis() + a.repeatMinutes * 60_000L)
        }
        finishAlarm()
    }

    private fun cleanup() {
        handler.removeCallbacks(timeout)
        player?.stop()
        player = null
        vibrator?.cancel()
        vibrator = null
        wake?.let { if (it.isHeld) it.release() }
        wake = null
    }

    private fun finishAlarm() {
        if (finished) return
        finished = true
        cleanup()
        sendBroadcast(Intent(ACTION_DONE).setPackage(packageName))
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }
}
