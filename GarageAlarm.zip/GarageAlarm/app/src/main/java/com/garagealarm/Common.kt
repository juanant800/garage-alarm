package com.garagealarm

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Calendar
import kotlin.math.min

object GColors {
    val Bg = Color(0xFF0E0E10)
    val Panel = Color(0xFF18181B)
    val Red = Color(0xFFFF3B30)
    val RedDark = Color(0xFFC42B22)
    val Hi = Color(0xFFF4F4F5)
    val Lo = Color(0xFF9A9CA3)
    val Chrome = Color(0xFFC9CCD1)
    val Chip = Color(0xFF232327)
}

@Composable
fun GarageTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = GColors.Red, onPrimary = Color.White,
            background = GColors.Bg, onBackground = GColors.Hi,
            surface = GColors.Panel, onSurface = GColors.Hi,
            surfaceVariant = GColors.Chip, onSurfaceVariant = GColors.Lo,
            outline = Color(0xFF3A3A40)
        ),
        content = content
    )
}

fun Modifier.panel(radius: Dp = 16.dp): Modifier {
    val shape = RoundedCornerShape(radius)
    return this
        .shadow(10.dp, shape, clip = false, ambientColor = Color.Black, spotColor = Color.Black)
        .clip(shape)
        .background(Brush.linearGradient(listOf(Color(0xFF232327), Color(0xFF141417))))
        .border(1.dp, Color(0x14FFFFFF), shape)
}

@Composable
fun T(
    text: String, size: Int, weight: FontWeight = FontWeight.Normal, color: Color = GColors.Hi,
    modifier: Modifier = Modifier, align: TextAlign? = null, spacing: Float = 0f
) {
    Text(
        text = text, modifier = modifier, color = color, fontSize = size.sp, fontWeight = weight,
        textAlign = align, letterSpacing = spacing.sp
    )
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(20.dp))
            .background(if (selected) GColors.Red else GColors.Chip)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) { T(text, 14, FontWeight.Medium, if (selected) Color.White else GColors.Hi) }
}

/** Placa gris con la silueta negra del coche. */
@Composable
fun CarPlate(car: CarProfile, modifier: Modifier = Modifier.size(112.dp, 46.dp)) {
    val path = remember(car.id) { PathParser().parsePathString(car.sil.body).toPath() }
    Box(
        modifier.clip(RoundedCornerShape(10.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFFE4E6EA), Color(0xFFB5B9C0)))),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize().padding(horizontal = 6.dp, vertical = 3.dp)) {
            val s = min(size.width / 120f, size.height / 40f)
            val ox = (size.width - 120f * s) / 2f
            val oy = (size.height - 40f * s) / 2f
            withTransform({ translate(ox, oy); scale(s, s, Offset.Zero) }) {
                drawPath(path, Color.Black)
                car.sil.rects.forEach { r -> drawRect(Color.Black, Offset(r[0], r[1]), Size(r[2], r[3])) }
                listOf(car.sil.rearX, car.sil.frontX).forEach { x ->
                    drawCircle(Color.Black, 7.5f, Offset(x, 31f))
                    drawCircle(Color(0xFFCDD0D5), 7.5f, Offset(x, 31f), style = Stroke(2f))
                }
            }
        }
    }
}

private fun DrawScope.hand(deg: Float, len: Float, w: Float, color: Color) {
    rotate(deg, Offset(150f, 150f)) {
        drawLine(Color.Black.copy(alpha = 0.55f), Offset(153f, 154f), Offset(153f, 154f - len), w, StrokeCap.Round)
        drawLine(color, Offset(150f, 150f), Offset(150f, 150f - len), w, StrokeCap.Round)
    }
}

/** Reloj analogico en forma de llanta con disco de freno y pinza roja. */
@Composable
fun TireClock(now: Long, modifier: Modifier = Modifier) {
    val cal = remember(now) { Calendar.getInstance().apply { timeInMillis = now } }
    val h = cal.get(Calendar.HOUR)
    val m = cal.get(Calendar.MINUTE)
    val sec = cal.get(Calendar.SECOND)
    val hourDeg = (h + m / 60f) * 30f
    val minDeg = (m + sec / 60f) * 6f
    Canvas(modifier) {
        val s = size.minDimension / 300f
        withTransform({ scale(s, s, Offset.Zero) }) {
            val c = Offset(150f, 150f)
            drawCircle(
                Brush.radialGradient(listOf(Color(0xFF2E2E33), Color(0xFF0F0F11)), Offset(150f, 105f), 215f),
                144f, c
            )
            drawCircle(Color(0xFF2A2A2F), 144f, c, style = Stroke(3f))
            drawCircle(
                Color(0xFF303036), 132f, c,
                style = Stroke(10f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(7f, 5f)))
            )
            drawCircle(
                Brush.radialGradient(listOf(Color(0xFF232327), Color(0xFF0A0A0B)), Offset(120f, 105f), 150f),
                112f, c
            )
            drawCircle(
                Brush.linearGradient(
                    listOf(Color(0xFFF2F4F7), Color(0xFF7C8087), Color(0xFFD5D8DD), Color(0xFF5A5D63)),
                    Offset(40f, 40f), Offset(260f, 260f)
                ),
                112f, c, style = Stroke(9f)
            )
            // disco de freno + pinza roja
            drawCircle(Color(0xFF2A2A2F), 78f, c)
            drawCircle(Color(0xFF4A4A51), 78f, c, style = Stroke(2f))
            drawCircle(Color(0xFF3A3A40), 46f, c, style = Stroke(2f))
            drawArc(GColors.RedDark, -30f, 50f, false, Offset(72f, 72f), Size(156f, 156f), style = Stroke(18f, cap = StrokeCap.Round))
            drawArc(GColors.Red, -30f, 50f, false, Offset(72f, 72f), Size(156f, 156f), style = Stroke(12f, cap = StrokeCap.Round))
            // marcas
            for (i in 0 until 12) {
                val major = i % 3 == 0
                rotate(i * 30f, c) {
                    drawLine(
                        if (major) GColors.Red else Color(0xFF8A8D93),
                        Offset(150f, 48f), Offset(150f, 60f), if (major) 5f else 3f
                    )
                }
            }
            hand(hourDeg, 50f, 8f, GColors.Hi)
            hand(minDeg, 84f, 4f, GColors.Red)
            drawCircle(
                Brush.linearGradient(listOf(Color(0xFFF2F4F7), Color(0xFF5A5D63)), Offset(137f, 137f), Offset(163f, 163f)),
                13f, c
            )
            drawCircle(GColors.Red, 5f, c)
        }
    }
}

/** Cuentarrevoluciones animado (decorativo) para la pantalla de alarma. */
@Composable
fun Tachometer(rev: Float, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val s = size.minDimension / 220f
        withTransform({ scale(s, s, Offset.Zero) }) {
            val c = Offset(110f, 110f)
            drawCircle(Color(0xFF141417), 108f, c)
            drawCircle(Color(0xFF3A3A40), 108f, c, style = Stroke(3f))
            drawArc(Color(0xFF2A2A2F), 150f, 240f, false, Offset(20f, 20f), Size(180f, 180f), style = Stroke(10f))
            drawArc(GColors.Red, 150f + 240f * 0.8f, 240f * 0.2f, false, Offset(20f, 20f), Size(180f, 180f), style = Stroke(10f))
            for (i in 0..8) {
                rotate(150f + 30f * i, c) {
                    drawLine(if (i >= 7) GColors.Red else GColors.Chrome, Offset(196f, 110f), Offset(184f, 110f), 3f)
                }
            }
            rotate(150f + 240f * rev, c) {
                drawLine(Color.Black.copy(alpha = 0.5f), Offset(112f, 113f), Offset(182f, 113f), 5f, StrokeCap.Round)
                drawLine(GColors.Red, Offset(110f, 110f), Offset(180f, 110f), 4f, StrokeCap.Round)
            }
            drawCircle(GColors.Chrome, 9f, c)
            drawCircle(GColors.Red, 4f, c)
        }
    }
}

/** Boton que hay que mantener pulsado para completar la accion. */
@Composable
fun HoldButton(text: String, holdMs: Int = 1800, onDone: () -> Unit) {
    var progress by remember { mutableFloatStateOf(0f) }
    val scope = rememberCoroutineScope()
    Box(
        Modifier.fillMaxWidth().height(72.dp)
            .clip(RoundedCornerShape(36.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF232327), Color(0xFF141417))))
            .border(2.dp, GColors.Red, RoundedCornerShape(36.dp))
            .pointerInput(Unit) {
                detectTapGestures(onPress = {
                    val j = scope.launch {
                        val st = System.currentTimeMillis()
                        while (true) {
                            val p = (System.currentTimeMillis() - st) / holdMs.toFloat()
                            progress = p.coerceAtMost(1f)
                            if (p >= 1f) { onDone(); break }
                            delay(16)
                        }
                    }
                    tryAwaitRelease()
                    j.cancel()
                    if (progress < 1f) progress = 0f
                })
            },
        contentAlignment = Alignment.CenterStart
    ) {
        Box(
            Modifier.fillMaxSize().clip(RoundedCornerShape(36.dp))
        ) {
            Box(
                Modifier.fillMaxHeight().fillMaxWidth(progress)
                    .background(Brush.horizontalGradient(listOf(GColors.RedDark, GColors.Red)))
            )
        }
        Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
            T(text, 17, FontWeight.Bold, Color.White, Modifier.fillMaxWidth(), TextAlign.Center)
        }
    }
}
