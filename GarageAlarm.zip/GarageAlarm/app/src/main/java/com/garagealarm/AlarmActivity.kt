package com.garagealarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import java.util.Calendar

class AlarmActivity : ComponentActivity() {
    private var alarm by mutableStateOf<Alarm?>(null)
    private var repeatIdx by mutableIntStateOf(0)

    private val doneReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { finish() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        readIntent(intent)
        ContextCompat.registerReceiver(this, doneReceiver, IntentFilter(AlarmService.ACTION_DONE), ContextCompat.RECEIVER_NOT_EXPORTED)
        setContent {
            GarageTheme {
                val a = alarm
                if (a != null) {
                    RingScreen(
                        a, repeatIdx,
                        onStop = { send(AlarmService.ACTION_STOP) },
                        onSnooze = { send(AlarmService.ACTION_SNOOZE) }
                    )
                } else Box(Modifier.fillMaxSize().background(GColors.Bg))
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readIntent(intent)
    }

    private fun readIntent(i: Intent) {
        alarm = AlarmRepo.get(this, i.getIntExtra(AlarmScheduler.EXTRA_ID, -1))
        repeatIdx = i.getIntExtra(AlarmScheduler.EXTRA_REPEAT, 0)
        if (alarm == null) finish()
    }

    private fun send(action: String) {
        startService(Intent(this, AlarmService::class.java).setAction(action))
    }

    override fun onDestroy() {
        try { unregisterReceiver(doneReceiver) } catch (e: Exception) {}
        super.onDestroy()
    }
}

@Composable
fun RingScreen(a: Alarm, repeatIdx: Int, onStop: () -> Unit, onSnooze: () -> Unit) {
    val car = Cars.byId(a.carId)
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(1000L - now % 1000L) } }
    val cal = remember(now / 1000) { Calendar.getInstance().apply { timeInMillis = now } }
    val rev by rememberInfiniteTransition(label = "rev").animateFloat(
        initialValue = 0.12f, targetValue = 0.88f,
        animationSpec = infiniteRepeatable(tween(1300, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "revValue"
    )
    val canSnooze = a.repeatEnabled && repeatIdx < a.repeatTimes
    Column(
        Modifier.fillMaxSize()
            .background(Brush.radialGradient(listOf(Color(0xFF2A1210), GColors.Bg), radius = 1500f))
            .padding(horizontal = 24.dp, vertical = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            T(if (a.label.isBlank()) "ALARMA" else a.label.uppercase(), 13, color = GColors.Red, spacing = 3f)
            T("%02d:%02d".format(cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE)), 72, FontWeight.Bold)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Tachometer(rev, Modifier.size(230.dp))
            Spacer(Modifier.height(20.dp))
            CarPlate(car, Modifier.size(150.dp, 62.dp))
            T(car.name, 20, FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
            T(car.engine, 13, color = GColors.Lo)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            if (canSnooze) {
                Box(
                    Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(28.dp))
                        .background(GColors.Chip).border(1.dp, Color(0xFF3A3A40), RoundedCornerShape(28.dp))
                        .clickable(onClick = onSnooze),
                    contentAlignment = Alignment.Center
                ) {
                    T("Posponer ${a.repeatMinutes} min · ${a.repeatTimes - repeatIdx} restantes", 15, FontWeight.Medium, align = TextAlign.Center)
                }
            }
            HoldButton("Mantén pulsado para apagar el motor", onDone = onStop)
        }
    }
}
