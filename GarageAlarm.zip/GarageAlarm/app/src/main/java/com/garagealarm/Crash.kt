package com.garagealarm

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun CrashScreen(text: String, onCopy: () -> Unit, onClearAlarms: () -> Unit, onContinue: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(GColors.Bg).statusBarsPadding().navigationBarsPadding().padding(20.dp)
    ) {
        T("La app tuvo un error", 22, FontWeight.Bold)
        T(
            "Pulsa «Copiar error» y pégaselo a Claude para que lo arregle.", 14, color = GColors.Lo,
            modifier = Modifier.padding(top = 6.dp, bottom = 12.dp)
        )
        Box(Modifier.weight(1f).fillMaxWidth().panel(12.dp).verticalScroll(rememberScrollState()).padding(12.dp)) {
            Text(text, color = GColors.Hi, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
        }
        Spacer(Modifier.height(12.dp))
        BigButton("Copiar error", true, onCopy)
        Spacer(Modifier.height(8.dp))
        BigButton("Borrar alarmas y continuar", false, onClearAlarms)
        Spacer(Modifier.height(8.dp))
        BigButton("Continuar", false, onContinue)
    }
}

@Composable
fun BigButton(text: String, primary: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(26.dp))
            .background(if (primary) GColors.Red else GColors.Chip).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { T(text, 15, FontWeight.Medium, Color.White) }
}
