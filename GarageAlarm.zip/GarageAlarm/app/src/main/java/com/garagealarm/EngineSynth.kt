package com.garagealarm

import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.tanh

/**
 * Sintetizador de motor en tiempo real (sin Android): genera PCM 16-bit mono.
 *
 * Secuencia: arranque (motor de arranque) -> el motor prende y se estabiliza al ralenti
 * -> aceleradas cada vez mas largas y fuertes hasta casi corte de encendido.
 * El volumen sube poco a poco durante [rampSec] segundos.
 */
class EngineSynth(
    private val car: CarProfile,
    private val sr: Int,
    private val idleSec: Double,
    private val rampSec: Double,
    private val startVol: Double = 0.25,
    private val quick: Boolean = false
) {
    private val n = car.cyl
    private val off = DoubleArray(n) { it.toDouble() / n }
    private val bias = DoubleArray(n) { if (it % 2 == 0) car.lump * 0.8 else -car.lump * 0.8 }
    private val amp = DoubleArray(n) { 1.0 }
    private var seed = 0x2545F491L

    private fun rnd(): Double {
        seed = seed xor (seed shl 13)
        seed = seed xor (seed ushr 7)
        seed = seed xor (seed shl 17)
        return ((seed ushr 11) and 0xFFFFFFL).toDouble() / 16777216.0
    }

    private var samples = 0L
    private var rpm = 0.0
    private var thr = 0.0
    private var phase = 0.0

    private var tgtRpm = 0.0
    private var tgtThr = 0.0
    private var prevTgtThr = 0.0
    private var crank = true

    private var dc = 0.0
    private var lp1 = 0.0
    private var lp2 = 0.0
    private var boomLp = 0.0
    private var nLp = 0.0
    private var lpA = 0.1
    private var ctl = 0
    private var whPh = 0.0
    private var starterPh = 0.0
    private var popEnv = 0.0
    private var bov = 0.0

    private val riseC = 1.0 - exp(-1.0 / (sr * car.riseTau))
    private val fallC = 1.0 - exp(-1.0 / (sr * 0.35))
    private val thrC = 1.0 - exp(-1.0 / (sr * 0.05))
    private val dcC = 1.0 - exp(-2.0 * PI * 25.0 / sr)
    private val boomC = 1.0 - exp(-2.0 * PI * 170.0 / sr)
    private val popDecay = exp(-1.0 / (0.02 * sr))
    private val bovDecay = exp(-1.0 / (0.28 * sr))
    private val twoPi = 2.0 * PI

    private fun control(t: Double) {
        val idle = car.idleRpm
        val red = car.redRpm
        val crankEnd = if (quick) 1.2 else 2.4
        crank = t < crankEnd
        if (crank) {
            tgtRpm = 170.0 + 25.0 * sin(t * 11.0)
            tgtThr = 0.0
            return
        }
        val t1 = t - crankEnd
        if (t1 < 0.6) { // el motor prende y se pasa de vueltas un instante
            tgtRpm = idle * (1.0 + 0.9 * (1.0 - t1 / 0.6))
            tgtThr = 0.25
            return
        }
        val t2 = t1 - 0.6
        if (t2 < idleSec) {
            tgtRpm = idle + idle * 0.02 * sin(t2 * 3.1)
            tgtThr = 0.05
            return
        }
        var u = t2 - idleSec
        var k = 0
        while (true) {
            val kk = min(k, 8)
            val peak = idle + (red * 0.93 - idle) * min(1.0, 0.18 + 0.11 * k)
            val up = 0.35 + 0.07 * kk
            val hold = 0.12 + 0.04 * kk
            val fall = 0.7 + 0.04 * kk
            val pause = maxOf(0.6, 2.0 - 0.3 * k)
            val len = up + hold + fall + pause
            if (u < len) {
                when {
                    u < up -> {
                        val x = u / up
                        tgtRpm = idle + (peak - idle) * (x * x * (3.0 - 2.0 * x))
                        tgtThr = 1.0
                    }
                    u < up + hold -> {
                        tgtRpm = peak * (if (peak > red * 0.9 && sin(u * 70.0) > 0) 0.965 else 1.0)
                        tgtThr = 1.0
                    }
                    else -> {
                        tgtRpm = idle
                        tgtThr = 0.0
                    }
                }
                return
            }
            u -= len
            k++
        }
    }

    private fun rerollAmps(frac: Double) {
        val spread = car.lump * (1.0 - frac * 0.7)
        for (i in 0 until n) amp[i] = 1.0 + bias[i] + (rnd() * 2.0 - 1.0) * spread
    }

    fun fill(out: ShortArray, count: Int) {
        for (s in 0 until count) {
            val tt = samples.toDouble() / sr
            if (ctl <= 0) {
                ctl = 64
                control(tt)
                val fr = (rpm / car.redRpm).coerceIn(0.0, 1.0)
                var cut = car.cutLow + (car.cutHigh - car.cutLow) * fr.pow(0.8) * (0.45 + 0.55 * thr)
                if (crank) cut = car.cutLow * 0.55
                lpA = 1.0 - exp(-twoPi * cut / sr)
                if (prevTgtThr > 0.5 && tgtThr < 0.2 && fr > 0.4 && car.turbo > 0.0) bov = 1.0
                prevTgtThr = tgtThr
            }
            ctl--

            rpm += (tgtRpm - rpm) * (if (tgtRpm > rpm) riseC else fallC)
            thr += (tgtThr - thr) * thrC
            val frac = (rpm / car.redRpm).coerceIn(0.0, 1.0)

            phase += rpm / 120.0 / sr
            if (phase >= 1.0) { phase -= 1.0; rerollAmps(frac) }

            var p = 0.0
            for (i in 0 until n) {
                var x = phase - off[i]
                if (x < 0.0) x += 1.0
                val z = x * car.pulseK
                if (z < 14.0) p += amp[i] * z * exp(1.0 - z)
            }

            val load = if (crank) 0.3 else 0.30 + 0.70 * thr
            var x = p * load
            dc += (x - dc) * dcC
            x -= dc
            x = tanh(x * car.drive * (0.9 + 0.6 * thr))

            lp1 += (x - lp1) * lpA
            lp2 += (lp1 - lp2) * lpA
            boomLp += (x - boomLp) * boomC

            val nz = rnd() * 2.0 - 1.0
            nLp += (nz - nLp) * 0.35

            var y = lp2 + boomLp * car.boom * 0.5 + nLp * 0.14 * thr * (0.3 + frac)

            if (car.turbo > 0.0 && !crank) {
                whPh += twoPi * (2500.0 + 9000.0 * frac) / sr
                if (whPh > twoPi) whPh -= twoPi
                y += sin(whPh) * car.turbo * 0.035 * thr * frac * frac
                if (bov > 0.001) {
                    y += (nz - nLp) * bov * 0.12 * car.turbo
                    bov *= bovDecay
                }
            }
            if (!crank && thr < 0.15 && frac > 0.3 && rpm > tgtRpm + 200.0 && rnd() < car.pop * 0.00009) popEnv = 1.0
            if (popEnv > 0.001) {
                y += (nz * 0.7 + nLp * 0.3) * popEnv * 0.45
                popEnv *= popDecay
            }
            if (crank) {
                y += sin(starterPh) * 0.06
                starterPh += twoPi * (520.0 + 70.0 * sin(tt * 2.7)) / sr
                if (starterPh > twoPi) starterPh -= twoPi
            }

            val g = startVol + (1.0 - startVol) * min(1.0, tt / rampSec)
            val z = tanh(y * 1.6) * g * 0.92
            out[s] = (z * 32767.0).toInt().toShort()
            samples++
        }
    }
}
