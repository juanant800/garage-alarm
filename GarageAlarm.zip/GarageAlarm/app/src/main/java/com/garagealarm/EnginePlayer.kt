package com.garagealarm

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaPlayer
import kotlin.math.max
import kotlin.math.min

/**
 * Reproduce el motor del coche. Si existe res/raw/car_<id>_sample.(mp3|wav|ogg) se usa esa
 * grabacion real (en bucle, con subida de volumen); si no, se sintetiza en tiempo real.
 */
class EnginePlayer(private val ctx: Context) {
    @Volatile private var running = false
    private var thread: Thread? = null
    private var mp: MediaPlayer? = null

    fun start(car: CarProfile, idleSec: Int, rampSec: Int, startVol: Float, quick: Boolean = false) {
        stop()
        running = true
        val attrs = AudioAttributes.Builder()
            .setUsage(if (quick) AudioAttributes.USAGE_MEDIA else AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
        val resId = ctx.resources.getIdentifier("car_${car.id}_sample", "raw", ctx.packageName)
        thread = if (resId != 0) {
            Thread { runSample(resId, attrs, rampSec, startVol) }
        } else {
            Thread { runSynth(car, attrs, idleSec, rampSec, startVol, quick) }
        }
        thread!!.priority = Thread.MAX_PRIORITY
        thread!!.start()
    }

    private fun runSynth(car: CarProfile, attrs: AudioAttributes, idle: Int, ramp: Int, startVol: Float, quick: Boolean) {
        val sr = 32000
        val minBuf = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        var track: AudioTrack? = null
        try {
            track = AudioTrack.Builder()
                .setAudioAttributes(attrs)
                .setAudioFormat(
                    AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
                )
                .setBufferSizeInBytes(max(minBuf, sr / 5 * 2))
                .setTransferMode(AudioTrack.MODE_STREAM).build()
            track.play()
            val synth = EngineSynth(car, sr, idle.toDouble(), max(1, ramp).toDouble(), startVol.toDouble(), quick)
            val buf = ShortArray(1024)
            while (running) {
                synth.fill(buf, buf.size)
                if (track.write(buf, 0, buf.size) < 0) break
            }
        } catch (e: Exception) {
            // sin audio: el servicio sigue vivo y vibra
        } finally {
            try { track?.stop() } catch (e: Exception) {}
            track?.release()
        }
    }

    private fun runSample(resId: Int, attrs: AudioAttributes, ramp: Int, startVol: Float) {
        try {
            val p = MediaPlayer.create(ctx, resId, attrs, 0) ?: return
            mp = p
            p.isLooping = true
            p.setVolume(startVol, startVol)
            p.start()
            val t0 = System.currentTimeMillis()
            while (running) {
                val f = min(1f, (System.currentTimeMillis() - t0) / (max(1, ramp) * 1000f))
                val v = startVol + (1f - startVol) * f
                p.setVolume(v, v)
                Thread.sleep(250)
            }
        } catch (e: Exception) {
        } finally {
            try { mp?.stop() } catch (e: Exception) {}
            mp?.release()
            mp = null
        }
    }

    fun stop() {
        running = false
        thread?.let { t -> try { t.join(800) } catch (e: Exception) {} }
        thread = null
    }
}
