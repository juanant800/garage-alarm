package com.garagealarm

import android.text.format.DateFormat
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.TimePicker
import androidx.compose.material3.TimePickerDefaults
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class PermIssue(val text: String, val button: String)

@Composable
fun App(vm: AlarmViewModel, issue: PermIssue?, onFix: () -> Unit) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val ed = vm.editing
    if (ed != null) {
        BackHandler { vm.editing = null }
        EditorScreen(vm, ed)
    } else {
        Column(
            Modifier.fillMaxSize()
                .background(Brush.radialGradient(listOf(Color(0xFF1D1D21), GColors.Bg), radius = 1400f))
                .statusBarsPadding().navigationBarsPadding()
        ) {
            if (issue != null) PermBanner(issue, onFix)
            Box(Modifier.weight(1f)) {
                when (tab) {
                    0 -> ClockScreen(vm)
                    1 -> AlarmsScreen(vm)
                    else -> MotorScreen(vm)
                }
            }
            BottomBar(tab) { tab = it }
        }
    }
}

@Composable
fun PermBanner(issue: PermIssue, onFix: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(12.dp).panel().border(1.dp, GColors.Red, RoundedCornerShape(16.dp)).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        T(issue.text, 13, color = GColors.Hi, modifier = Modifier.weight(1f))
        Spacer(Modifier.width(10.dp))
        Chip(issue.button, true, onFix)
    }
}

@Composable
fun BottomBar(selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFF1A1A1E), Color(0xFF111113))))) {
        listOf("Reloj", "Alarmas", "Motor").forEachIndexed { i, name ->
            Column(
                Modifier.weight(1f).height(60.dp).clickable { onSelect(i) },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(Modifier.fillMaxWidth().height(3.dp).background(if (i == selected) GColors.Red else Color.Transparent))
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    T(name, 14, FontWeight.Medium, if (i == selected) GColors.Red else GColors.Lo)
                }
            }
        }
    }
}

@Composable
fun Header(small: String?, title: String, trailing: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(start = 24.dp, end = 20.dp, top = 20.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            if (small != null) T(small, 13, color = GColors.Lo, spacing = 3f)
            T(title, 28, FontWeight.Bold)
        }
        trailing?.invoke()
    }
}

// ---------------------------------------------------------------- RELOJ
@Composable
fun ClockScreen(vm: AlarmViewModel) {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1000L - now % 1000L)
        }
    }
    val time = remember(now / 1000) { SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(now)) }
    val date = remember(now / 60000) {
        SimpleDateFormat("EEEE, d 'de' MMMM", Locale("es", "ES")).format(Date(now)).replaceFirstChar { it.uppercase() }
    }
    val next = vm.alarms.filter { it.enabled }.map { it to nextTrigger(it, now) }.minByOrNull { it.second }
    Column(Modifier.fillMaxSize()) {
        Header("GARAGE ALARM", "Reloj")
        Column(
            Modifier.weight(1f).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(22.dp, Alignment.CenterVertically)
        ) {
            TireClock(now, Modifier.size(310.dp))
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                T(time, 56, FontWeight.Bold, spacing = 2f)
                T(date, 15, color = GColors.Lo)
            }
            Row(Modifier.panel().padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(if (next != null) GColors.Red else GColors.Lo))
                Spacer(Modifier.width(12.dp))
                if (next != null) {
                    val (a, t) = next
                    Column {
                        T("Próxima: %02d:%02d · %s".format(a.hour, a.minute, Cars.byId(a.carId).name), 15)
                        T("Sonará dentro de " + describeUntil(t, now), 12, color = GColors.Lo)
                    }
                } else {
                    T("Sin alarmas activas", 15, color = GColors.Lo)
                }
            }
        }
    }
}

// ---------------------------------------------------------------- ALARMAS
@Composable
fun AlarmsScreen(vm: AlarmViewModel) {
    Column(Modifier.fillMaxSize()) {
        Header(null, "Alarmas") {
            Box(
                Modifier.size(48.dp)
                    .shadow(8.dp, CircleShape, ambientColor = GColors.Red, spotColor = GColors.Red)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(Color(0xFFFF5A4F), GColors.RedDark)))
                    .clickable { vm.newAlarm() },
                contentAlignment = Alignment.Center
            ) { T("+", 28, FontWeight.Medium, Color.White) }
        }
        if (vm.alarms.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                T("Pulsa + para crear tu primera alarma", 15, color = GColors.Lo)
            }
        } else {
            LazyColumn(
                Modifier.weight(1f),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(vm.alarms, key = { it.id }) { a -> AlarmCard(a, vm) }
            }
        }
    }
}

@Composable
fun SwitchRed(checked: Boolean, onChange: (Boolean) -> Unit) {
    Switch(
        checked = checked, onCheckedChange = onChange,
        colors = SwitchDefaults.colors(
            checkedTrackColor = GColors.Red, checkedThumbColor = Color.White, checkedBorderColor = Color.Transparent,
            uncheckedTrackColor = Color(0xFF3A3A40), uncheckedThumbColor = Color.White, uncheckedBorderColor = Color.Transparent
        )
    )
}

@Composable
fun AlarmCard(a: Alarm, vm: AlarmViewModel) {
    val car = Cars.byId(a.carId)
    val rep = if (a.repeatEnabled) "Repetir ${a.repeatTimes}× cada ${a.repeatMinutes} min" else "Sin repetición"
    Row(
        Modifier.fillMaxWidth().panel().clickable { vm.edit(a) }.padding(horizontal = 20.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            T("%02d:%02d".format(a.hour, a.minute), 38, FontWeight.Bold, if (a.enabled) GColors.Hi else GColors.Lo)
            T(
                (if (a.label.isBlank()) "" else a.label + " · ") + daysText(a.days) + " · " + car.name,
                14, color = GColors.Lo, modifier = Modifier.padding(top = 2.dp)
            )
            T(rep, 13, color = if (a.enabled) GColors.Red else GColors.Lo, modifier = Modifier.padding(top = 6.dp))
        }
        SwitchRed(a.enabled) { vm.toggle(a, it) }
    }
}

// ---------------------------------------------------------------- MOTOR
@Composable
fun MotorScreen(vm: AlarmViewModel) {
    val ctx = LocalContext.current
    val player = remember { EnginePlayer(ctx.applicationContext) }
    var playing by remember { mutableStateOf(false) }
    DisposableEffect(Unit) { onDispose { player.stop() } }
    LaunchedEffect(playing, vm.defaultCar) {
        if (playing) {
            player.start(Cars.byId(vm.defaultCar), 2, 3, 0.6f, quick = true)
            delay(45_000)
            playing = false
        } else {
            player.stop()
        }
    }
    Column(Modifier.fillMaxSize()) {
        Header("SONIDO DE ALARMA", "Motor")
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 20.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(Cars.all, key = { it.id }) { car ->
                val sel = car.id == vm.defaultCar
                Row(
                    Modifier.fillMaxWidth().panel(14.dp)
                        .border(2.dp, if (sel) GColors.Red else Color.Transparent, RoundedCornerShape(14.dp))
                        .clickable { vm.setDefaultCar(car.id) }
                        .padding(start = 18.dp, end = 12.dp, top = 8.dp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        T(car.name, 16, FontWeight.Bold)
                        T(car.engine, 12, color = GColors.Lo)
                    }
                    CarPlate(car)
                }
            }
            item {
                Column(Modifier.fillMaxWidth().padding(top = 4.dp).panel(14.dp).padding(horizontal = 18.dp, vertical = 14.dp)) {
                    T("Secuencia de despertar", 14, color = GColors.Lo)
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.height(48.dp).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.Bottom) {
                        listOf(0.25f to 0, 0.25f to 0, 0.55f to 1, 0.35f to 1, 0.8f to 2, 0.45f to 2, 1f to 3).forEach { (h, lvl) ->
                            val col = listOf(Color(0xFF3A3A40), Color(0xFF7A1E19), Color(0xFFC42B22), GColors.Red)[lvl]
                            Box(Modifier.weight(1f).fillMaxWidth().height((48 * h).dp).background(col))
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        T("Arranque y ralentí", 13, color = GColors.Hi)
                        T("Aceleradas", 13, color = GColors.Hi)
                    }
                }
            }
            item {
                Box(
                    Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 12.dp).height(56.dp)
                        .clip(RoundedCornerShape(28.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFFFF5A4F), GColors.RedDark)))
                        .clickable { playing = !playing },
                    contentAlignment = Alignment.Center
                ) { T(if (playing) "Parar" else "Probar motor", 16, FontWeight.Bold, Color.White) }
            }
        }
    }
}

// ---------------------------------------------------------------- EDITOR
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(vm: AlarmViewModel, orig: Alarm) {
    val ctx = LocalContext.current
    var a by remember(orig.id) { mutableStateOf(orig) }
    val ts = rememberTimePickerState(orig.hour, orig.minute, DateFormat.is24HourFormat(ctx))
    val player = remember { EnginePlayer(ctx.applicationContext) }
    var playing by remember { mutableStateOf(false) }
    DisposableEffect(Unit) { onDispose { player.stop() } }
    LaunchedEffect(playing) {
        if (playing) {
            player.start(Cars.byId(a.carId), a.idleSeconds.coerceAtMost(4), 3, 0.6f, quick = true)
            delay(30_000)
            playing = false
        } else player.stop()
    }
    val dayNames = listOf("L", "M", "X", "J", "V", "S", "D")

    Column(
        Modifier.fillMaxSize()
            .background(Brush.radialGradient(listOf(Color(0xFF1D1D21), GColors.Bg), radius = 1400f))
            .statusBarsPadding().navigationBarsPadding()
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.clip(RoundedCornerShape(20.dp)).clickable { vm.editing = null }.padding(horizontal = 12.dp, vertical = 10.dp)) {
                T("Cancelar", 15, color = GColors.Lo)
            }
            T(if (vm.isNew) "Nueva alarma" else "Editar alarma", 18, FontWeight.Bold, modifier = Modifier.weight(1f), align = TextAlign.Center)
            Chip("Guardar", true) { vm.save(a.copy(hour = ts.hour, minute = ts.minute, enabled = true)) }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                TimePicker(
                    state = ts,
                    colors = TimePickerDefaults.colors(
                        clockDialColor = GColors.Panel, selectorColor = GColors.Red, containerColor = GColors.Bg,
                        clockDialSelectedContentColor = Color.White, clockDialUnselectedContentColor = GColors.Hi,
                        timeSelectorSelectedContainerColor = Color(0x40FF3B30), timeSelectorUnselectedContainerColor = GColors.Chip,
                        timeSelectorSelectedContentColor = Color.White, timeSelectorUnselectedContentColor = GColors.Hi
                    )
                )
            }

            Section("Días") {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    dayNames.forEachIndexed { i, n ->
                        val on = (a.days and (1 shl i)) != 0
                        Box(
                            Modifier.size(42.dp).clip(CircleShape)
                                .background(if (on) GColors.Red else GColors.Chip)
                                .clickable { a = a.copy(days = a.days xor (1 shl i)) },
                            contentAlignment = Alignment.Center
                        ) { T(n, 15, FontWeight.Bold, if (on) Color.White else GColors.Lo) }
                    }
                }
                T(daysText(a.days), 12, color = GColors.Lo, modifier = Modifier.padding(top = 8.dp))
            }

            OutlinedTextField(
                value = a.label, onValueChange = { a = a.copy(label = it.take(30)) },
                label = { T("Nombre (opcional)", 13, color = GColors.Lo) },
                singleLine = true, modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GColors.Red, unfocusedBorderColor = Color(0xFF3A3A40),
                    focusedTextColor = GColors.Hi, unfocusedTextColor = GColors.Hi, cursorColor = GColors.Red
                )
            )

            Section("Motor") {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(Cars.all, key = { it.id }) { car ->
                        val sel = car.id == a.carId
                        Column(
                            Modifier.width(150.dp).panel(14.dp)
                                .border(2.dp, if (sel) GColors.Red else Color.Transparent, RoundedCornerShape(14.dp))
                                .clickable { a = a.copy(carId = car.id) }.padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            CarPlate(car, Modifier.fillMaxWidth().height(50.dp))
                            T(car.name, 13, FontWeight.Bold, modifier = Modifier.padding(top = 8.dp), align = TextAlign.Center)
                            T(car.engine, 11, color = GColors.Lo, align = TextAlign.Center)
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Box(
                    Modifier.clip(RoundedCornerShape(20.dp)).background(GColors.Chip).clickable { playing = !playing }
                        .padding(horizontal = 18.dp, vertical = 12.dp)
                ) { T(if (playing) "Parar prueba" else "Probar este motor", 14, FontWeight.Medium) }
            }

            Section("Secuencia de despertar") {
                T("Ralentí antes de las aceleradas: ${a.idleSeconds} s", 14)
                RedSlider(a.idleSeconds.toFloat(), 3f..30f) { a = a.copy(idleSeconds = it.toInt()) }
                T("Tiempo hasta volumen máximo: ${a.rampSeconds} s", 14)
                RedSlider(a.rampSeconds.toFloat(), 10f..120f) { a = a.copy(rampSeconds = it.toInt()) }
            }

            Section("Repetición") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    T("Volver a sonar al posponer", 15, modifier = Modifier.weight(1f))
                    SwitchRed(a.repeatEnabled) { a = a.copy(repeatEnabled = it) }
                }
                if (a.repeatEnabled) {
                    T("Número de repeticiones", 13, color = GColors.Lo, modifier = Modifier.padding(top = 10.dp, bottom = 6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(listOf(1, 2, 3, 5, 10)) { n -> Chip("$n", a.repeatTimes == n) { a = a.copy(repeatTimes = n) } }
                    }
                    T("Cada cuántos minutos", 13, color = GColors.Lo, modifier = Modifier.padding(top = 10.dp, bottom = 6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(listOf(1, 5, 10, 15, 30)) { n -> Chip("$n min", a.repeatMinutes == n) { a = a.copy(repeatMinutes = n) } }
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                T("Vibración", 15, modifier = Modifier.weight(1f))
                SwitchRed(a.vibrate) { a = a.copy(vibrate = it) }
            }

            if (!vm.isNew) {
                Box(
                    Modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(26.dp))
                        .border(1.dp, GColors.Red, RoundedCornerShape(26.dp))
                        .clickable { vm.delete(orig) },
                    contentAlignment = Alignment.Center
                ) { T("Eliminar alarma", 15, FontWeight.Medium, GColors.Red) }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
fun Section(title: String, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().panel().padding(16.dp)) {
        T(title.uppercase(), 12, FontWeight.Medium, GColors.Lo, spacing = 2f)
        Spacer(Modifier.height(12.dp))
        content()
    }
}

@Composable
fun RedSlider(value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Slider(
        value = value, onValueChange = onChange, valueRange = range,
        colors = SliderDefaults.colors(
            thumbColor = GColors.Red, activeTrackColor = GColors.Red, inactiveTrackColor = Color(0xFF3A3A40)
        )
    )
}
