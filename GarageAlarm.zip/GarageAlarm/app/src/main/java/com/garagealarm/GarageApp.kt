package com.garagealarm

import android.app.Application
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/** Guarda en un archivo cualquier error que cierre la app, para mostrarlo al volver a abrirla. */
class GarageApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                val sw = StringWriter()
                error.printStackTrace(PrintWriter(sw))
                File(filesDir, "crash.txt").writeText("Hilo: " + thread.name + "\n" + sw.toString())
            } catch (e: Throwable) {
            }
            previous?.uncaughtException(thread, error)
        }
    }
}
