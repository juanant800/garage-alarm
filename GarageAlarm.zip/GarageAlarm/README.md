# Garage Alarm

Alarma para Android con tema de coches. Despierta con un motor que arranca, se queda al
ralentí y va dando aceleradas cada vez más fuertes mientras sube el volumen.

## Instalar en tu Samsung S23
1. Instala Android Studio (Hedgehog o más nuevo) y abre esta carpeta (File > Open).
2. Espera a que termine el Gradle Sync (descarga Gradle 8.5 y las librerías solo).
3. En el móvil: Ajustes > Acerca del teléfono > Información de software > toca 7 veces
   "Número de compilación"; luego Ajustes > Opciones de desarrollador > Depuración USB.
4. Conecta el móvil por USB, acepta la depuración y pulsa el botón Run (triángulo verde).

## Para que nunca falle la alarma
- Acepta los permisos de notificaciones y de notificaciones a pantalla completa
  (la app te avisa con un banner si falta alguno).
- Ajustes > Batería > Límites de uso en segundo plano: quita Garage Alarm de
  "Apps en suspensión" / "Apps en suspensión profunda".
- El volumen es el de ALARMA del sistema (Ajustes > Sonidos > Volumen).

## Sonidos
Por defecto el motor se SINTETIZA en tiempo real (cilindros, régimen, turbo, petardeos...)
con un perfil distinto por coche (src/main/java/com/garagealarm/Cars.kt).
Para usar grabaciones reales con licencia propia, copia un audio a
app/src/main/res/raw/ con el nombre car_<id>_sample.mp3 (o .wav/.ogg), por ejemplo:
car_f8_sample.mp3, car_mustang_sample.mp3, car_r34_sample.mp3, car_gt3_sample.mp3,
car_supra_sample.mp3, car_m4e46_sample.mp3, car_m5e60_sample.mp3.
Se reproducirá en bucle con subida de volumen en lugar del sintetizador.

## Añadir un coche
Añade un CarProfile en Cars.kt (cilindros, ralentí, límite de revoluciones, carácter del
sonido y silueta). Aparece solo en la app.
