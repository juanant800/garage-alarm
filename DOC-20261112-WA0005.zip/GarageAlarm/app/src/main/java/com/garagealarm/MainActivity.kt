package com.garagealarm

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val vm: AlarmViewModel by viewModels()
    private var issue by mutableStateOf<PermIssue?>(null)

    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { refreshIssue() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent {
            GarageTheme { App(vm, issue) { fixIssue() } }
        }
    }

    override fun onResume() {
        super.onResume()
        vm.reload()
        refreshIssue()
        AlarmScheduler.rescheduleAll(this)
    }

    private fun refreshIssue() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        issue = when {
            !nm.areNotificationsEnabled() ->
                PermIssue("Activa las notificaciones para que la alarma pueda mostrarse con la pantalla bloqueada.", "Activar")
            Build.VERSION.SDK_INT >= 34 && !nm.canUseFullScreenIntent() ->
                PermIssue("Permite las notificaciones a pantalla completa para que la alarma aparezca al sonar.", "Permitir")
            else -> null
        }
    }

    private fun fixIssue() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val i = if (!nm.areNotificationsEnabled()) {
            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
        } else if (Build.VERSION.SDK_INT >= 34) {
            Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName"))
        } else return
        startActivity(i)
    }
}
