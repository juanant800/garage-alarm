package com.garagealarm

import android.app.Application
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel

class AlarmViewModel(private val app: Application) : AndroidViewModel(app) {
    val alarms = mutableStateListOf<Alarm>()
    var editing by mutableStateOf<Alarm?>(null)
    var isNew by mutableStateOf(false)
    var defaultCar by mutableStateOf("f8")

    init { reload() }

    fun reload() {
        alarms.clear()
        alarms.addAll(AlarmRepo.load(app).sortedBy { it.hour * 60 + it.minute })
        defaultCar = AlarmRepo.defaultCar(app)
    }

    private fun persist() {
        alarms.sortBy { it.hour * 60 + it.minute }
        AlarmRepo.save(app, alarms.toList())
    }

    fun newAlarm() {
        val id = (alarms.maxOfOrNull { it.id } ?: 0) + 1
        editing = Alarm(id = id, hour = 7, minute = 0, carId = defaultCar)
        isNew = true
    }

    fun edit(a: Alarm) { editing = a; isNew = false }

    fun save(a: Alarm) {
        val i = alarms.indexOfFirst { it.id == a.id }
        if (i >= 0) alarms[i] = a else alarms.add(a)
        persist()
        AlarmScheduler.schedule(app, a)
        if (a.enabled) {
            val now = System.currentTimeMillis()
            Toast.makeText(app, "Sonará dentro de " + describeUntil(nextTrigger(a, now), now), Toast.LENGTH_LONG).show()
        }
        editing = null
    }

    fun delete(a: Alarm) {
        AlarmScheduler.cancel(app, a.id)
        alarms.removeAll { it.id == a.id }
        persist()
        editing = null
    }

    fun toggle(a: Alarm, on: Boolean) {
        val n = a.copy(enabled = on)
        val i = alarms.indexOfFirst { it.id == a.id }
        if (i >= 0) alarms[i] = n
        persist()
        AlarmScheduler.schedule(app, n)
    }

    fun setDefaultCar(id: String) {
        defaultCar = id
        AlarmRepo.setDefaultCar(app, id)
    }
}
